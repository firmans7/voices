-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 06 Feb 2020 pada 02.25
-- Versi Server: 5.5.34
-- Versi PHP: 5.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `db_voice_control`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_alat`
--

CREATE TABLE IF NOT EXISTS `tb_alat` (
  `alat_id` int(7) NOT NULL AUTO_INCREMENT,
  `alat_nama` varchar(255) NOT NULL,
  `alat_ruang` int(7) NOT NULL,
  `alat_kondisi` int(7) NOT NULL,
  PRIMARY KEY (`alat_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `tb_alat`
--

INSERT INTO `tb_alat` (`alat_id`, `alat_nama`, `alat_ruang`, `alat_kondisi`) VALUES
(1, 'Lampu Taman', 2, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_ruang`
--

CREATE TABLE IF NOT EXISTS `tb_ruang` (
  `ruang_id` int(7) NOT NULL AUTO_INCREMENT,
  `ruang_nama` varchar(255) NOT NULL,
  PRIMARY KEY (`ruang_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `tb_ruang`
--

INSERT INTO `tb_ruang` (`ruang_id`, `ruang_nama`) VALUES
(1, 'Teras'),
(2, 'Taman');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
