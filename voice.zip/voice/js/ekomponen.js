(function() {

	var recStatus = document.getElementById('recStatus');
	var startRecBtn = document.getElementById('startRecBtn');
	var stopRecBtn = document.getElementById('stopRecBtn');

	var rec = null;
	try {
		rec = new webkitSpeechRecognition();
	}
	catch(e) {
    	document.querySelector('.msg').setAttribute('data-state', 'show');
    	startRecBtn.setAttribute('disabled', 'true');
    	stopRecBtn.setAttribute('disabled', 'true');
    }
    if (rec) {
		rec.continuous = true;
		rec.interimResults = false;
		rec.lang = 'en';

		var confidenceThreshold = 0.5;

		var userSaid = function(str, s) {
			return str.indexOf(s) > -1;
		}

		var highlightCommand = function(cmd) {
			var el = document.getElementById(cmd);
			el.setAttribute('data-state', 'highlight');
			setTimeout(function() {
				el.setAttribute('data-state', '');
			}, 3000);
		}

		rec.onresult = function(e) {

			for (var i = e.resultIndex; i < e.results.length; ++i) {

	       		if (e.results[i].isFinal) {

	       			if (parseFloat(e.results[i][0].confidence) >= parseFloat(confidenceThreshold)) {
		       			var str = e.results[i][0].transcript;
		       			console.log('Recognised: ' + str);
		       			if (userSaid(str, 'light')) {

		       				if (userSaid(str, 'off')) {
                      // Otomatid Update tabel dari Kondisi 1 Ke kondisi 0
		       				}

		       				else if (userSaid(str, 'on')) {
                    //// Otomatid Update tabel dari Kondisi 0 Ke kondisi 1
		       				}

		       			}
	       			}
	        	}
	    	}
		};

		var startRec = function() {
			rec.start();
			recStatus.innerHTML = 'recognising';
		}

		var stopRec = function() {
			rec.stop();
			recStatus.innerHTML = 'not recognising';
		}

		startRecBtn.addEventListener('click', startRec, false);
		stopRecBtn.addEventListener('click', stopRec, false);
	}
})();
